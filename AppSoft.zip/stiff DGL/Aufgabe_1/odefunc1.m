function f = odefunc1(t,y)

f = 3 - y;
function f = odefunc2(t,y)

f = -1000*y + 3000 - 2000*exp(-t);
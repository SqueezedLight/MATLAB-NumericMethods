function f = aufgabe4gfunc(t,y)


f = zeros(2,1);
f(1) = 998*y(1) + 1998*y(2);
f(2) = -999*y(1) - 1999*y(2);